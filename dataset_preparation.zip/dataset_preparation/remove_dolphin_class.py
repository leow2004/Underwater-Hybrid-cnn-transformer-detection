import json
from pathlib import Path

ROOT = Path(r"D:\DataSetPrep\Hybrid_Marine_COCO")
ANN_DIR = ROOT / "annotations"

DROP_CLASS = "Dolphin"

def clean_split(split):

    ann_path = ANN_DIR / f"instances_{split}.json"

    with open(ann_path, "r", encoding="utf-8") as f:
        coco = json.load(f)

    categories = coco["categories"]
    images = coco["images"]
    annotations = coco["annotations"]

    # Map category IDs to names
    id_to_name = {c["id"]: c["name"] for c in categories}

    # Keep categories except Dolphin
    kept_categories = [c for c in categories if c["name"] != DROP_CLASS]

    # Create new category IDs
    name_to_newid = {c["name"]: i for i, c in enumerate(kept_categories)}

    oldid_to_newid = {}
    new_categories = []

    for c in kept_categories:
        new_id = name_to_newid[c["name"]]
        oldid_to_newid[c["id"]] = new_id

        new_categories.append({
            "id": new_id,
            "name": c["name"],
            "supercategory": "marine"
        })

    # Filter annotations
    new_annotations = []
    ann_id = 0
    used_image_ids = set()

    for ann in annotations:

        cname = id_to_name.get(ann["category_id"])

        if cname == DROP_CLASS:
            continue

        if ann["category_id"] not in oldid_to_newid:
            continue

        ann2 = ann.copy()
        ann2["id"] = ann_id
        ann2["category_id"] = oldid_to_newid[ann["category_id"]]

        new_annotations.append(ann2)

        used_image_ids.add(ann2["image_id"])

        ann_id += 1

    # Remove images with no annotations
    new_images = [img for img in images if img["id"] in used_image_ids]

    # Reindex image IDs
    old_to_new_img = {img["id"]: i for i, img in enumerate(new_images)}

    for img in new_images:
        img["id"] = old_to_new_img[img["id"]]

    for ann in new_annotations:
        ann["image_id"] = old_to_new_img[ann["image_id"]]

    cleaned = {
        "info": coco["info"],
        "licenses": coco.get("licenses", []),
        "categories": new_categories,
        "images": new_images,
        "annotations": new_annotations
    }

    out_path = ANN_DIR / f"instances_{split}_clean.json"

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(cleaned, f, indent=2)

    print(f"\n{split.upper()} CLEANED")
    print("Images:", len(new_images))
    print("Annotations:", len(new_annotations))
    print("Categories:", len(new_categories))
    print("Saved:", out_path)


for s in ["train", "val", "test"]:
    clean_split(s)

print("\nDolphin class removed successfully.")