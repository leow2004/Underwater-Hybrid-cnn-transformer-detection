import json
import random
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(r"C:\Leo_Willcock_Dissertation_23023613")
DATASET_ROOT = ROOT / r"04_Datasets\Processed_datasets\Hybrid_Marine_COCO"
ANN_DIR = DATASET_ROOT / "annotations"

ANNOTATION_FILES = [
    ANN_DIR / "instances_train_final.json",
    ANN_DIR / "instances_val_final.json",
    ANN_DIR / "instances_test_final.json",
    ANN_DIR / "instances_train.json",
    ANN_DIR / "instances_val.json",
    ANN_DIR / "instances_test.json",
]

OUT_DIR = ROOT / r"03_Report_Figures\Figure_3_random_class_examples"
OUT_DIR.mkdir(parents=True, exist_ok=True)

random.seed(42)

# Index every image file in Hybrid_Marine_COCO
image_files = {}
for p in DATASET_ROOT.rglob("*"):
    if p.suffix.lower() in [".jpg", ".jpeg", ".png"]:
        image_files[p.name] = p

print(f"Found {len(image_files)} image files.")

all_class_examples = {}

for ann_path in ANNOTATION_FILES:
    if not ann_path.exists():
        continue

    print(f"Checking annotations: {ann_path.name}")

    with open(ann_path, "r", encoding="utf-8") as f:
        coco = json.load(f)

    categories = {c["id"]: c["name"] for c in coco["categories"]}
    images = {img["id"]: img for img in coco["images"]}

    annotations = coco["annotations"]
    random.shuffle(annotations)

    for ann in annotations:
        class_name = categories[ann["category_id"]]

        if class_name in all_class_examples:
            continue

        img = images.get(ann["image_id"])
        if img is None:
            continue

        file_name = Path(img["file_name"]).name
        img_path = image_files.get(file_name)

        if img_path is not None and img_path.exists():
            all_class_examples[class_name] = (ann, img, img_path, categories)

print(f"\nFound examples for {len(all_class_examples)} classes.")

for class_name, (ann, img, img_path, categories) in all_class_examples.items():
    image = Image.open(img_path).convert("RGB")
    draw = ImageDraw.Draw(image)

    x, y, w, h = ann["bbox"]
    x1, y1, x2, y2 = x, y, x + w, y + h

    draw.rectangle([x1, y1, x2, y2], outline="red", width=4)

    label = class_name
    text_position = (x1, max(0, y1 - 22))
    text_bbox = draw.textbbox(text_position, label)
    draw.rectangle(text_bbox, fill="red")
    draw.text(text_position, label, fill="white")

    safe_name = class_name.lower().replace(" ", "_").replace("-", "_")
    out_file = OUT_DIR / f"{safe_name}_example.png"
    image.save(out_file)

    print(f"Saved {class_name}: {out_file}")

print("\nDone. Output folder:")
print(OUT_DIR)