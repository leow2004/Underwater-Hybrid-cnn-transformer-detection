import json
from pathlib import Path
from collections import Counter

import matplotlib.pyplot as plt

ANN = Path(r"C:\Leo_Willcock_Dissertation_23023613\04_Datasets\Processed_datasets\Hybrid_Marine_COCO\annotations\instances_train_final.json")

OUT = Path(r"C:\Leo_Willcock_Dissertation_23023613\03_Report_Figures\figure_2_class_distribution.png")

with open(ANN, "r", encoding="utf-8") as f:
    coco = json.load(f)

id_to_name = {c["id"]: c["name"] for c in coco["categories"]}
counts = Counter()

for ann in coco["annotations"]:
    counts[id_to_name[ann["category_id"]]] += 1

classes = [c["name"] for c in coco["categories"]]
values = [counts.get(name, 0) for name in classes]

plt.figure(figsize=(12, 6))
plt.bar(classes, values)
plt.xlabel("Class")
plt.ylabel("Number of annotations")
plt.title("Class Distribution in the Final Training Split")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

OUT.parent.mkdir(parents=True, exist_ok=True)
plt.savefig(OUT, dpi=300)
plt.close()

print(f"Saved class distribution figure to: {OUT}")