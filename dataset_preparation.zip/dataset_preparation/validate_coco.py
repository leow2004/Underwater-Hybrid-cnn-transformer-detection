import json
from pathlib import Path

ROOT = Path(r"D:\DataSetPrep\Hybrid_Marine_COCO")
ANN_DIR = ROOT / "annotations"
IMG_DIR = ROOT / "images"

def validate(split):
    ann_path = ANN_DIR / f"instances_{split}.json"
    with open(ann_path, "r", encoding="utf-8") as f:
        coco = json.load(f)

    cats = {c["id"]: c["name"] for c in coco["categories"]}
    assert set(cats.keys()) == set(range(len(cats))), f"{split}: category ids not 0..N-1"

    images = {im["id"]: im for im in coco["images"]}
    img_folder = IMG_DIR / split

    missing_files = 0
    for im in images.values():
        if not (img_folder / im["file_name"]).exists():
            missing_files += 1

    bad_boxes = 0
    bad_cat = 0
    orphan = 0
    for ann in coco["annotations"]:
        if ann["image_id"] not in images:
            orphan += 1
            continue
        if ann["category_id"] not in cats:
            bad_cat += 1
        x, y, w, h = ann["bbox"]
        if w <= 0 or h <= 0:
            bad_boxes += 1

    print(f"\n[{split}] images={len(images)} anns={len(coco['annotations'])}")
    print(f"missing image files: {missing_files}")
    print(f"orphan annotations: {orphan}")
    print(f"bad category_id: {bad_cat}")
    print(f"bad bbox (w/h <=0): {bad_boxes}")

for s in ["train", "val", "test"]:
    validate(s)

print("\nValidation complete.")