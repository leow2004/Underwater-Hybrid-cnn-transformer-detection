import json
import os
import random
import shutil
from pathlib import Path

# ----------------------------
# CONFIG (EDIT THESE PATHS)
# ----------------------------
DUO_ROOT  = Path(r"D:\DataSetPrep\DUO dataset.v2i.coco")     # contains train/, test/
RUOD_ROOT = Path(r"D:\DataSetPrep\RUOD.v4i.coco")    # contains train/, valid/, test/
OUT_ROOT  = Path(r"D:\DataSetPrep\Hybrid_Marine_COCO")

SEED = 42
SPLIT = (0.70, 0.20, 0.10)  # train, val, test

# Marine-only unified classes (0..19)
UNIFIED_CLASSES = [
    "Clam",
    "Coral",
    "Dolphin",
    "Fish",
    "Jellyfish",
    "Nudibranch",
    "Octopus",
    "Stingray",
    "Sea-Urchin",
    "Shark",
    "Squid",
    "Starfish",
    "Whale",
    "Diver",
    "Holothurian",
    "Echinus",
    "Sea_Lion",
    "Sea_Anemone",
    "Cuttle_fish",
    "Scallop",
]

# Map dataset category "name" -> unified class name
# (We normalize RUOD names like "01_Clam" -> "Clam")
NAME_MAP = {
    # DUO
    "echinus": "Echinus",
    "holothurian": "Holothurian",
    "starfish": "Starfish",
    "scallop": "Scallop",
    # RUOD
    "01_Clam": "Clam",
    "02_Coral": "Coral",
    "04_Dolphin": "Dolphin",
    "06_Fish": "Fish",
    "07_Jellyfish": "Jellyfish",
    "09_Nudibranch": "Nudibranch",
    "10_Octopus": "Octopus",
    "14_Stingray": "Stingray",
    "15_Sea-Urchin": "Sea-Urchin",
    "16_Shark": "Shark",
    "18_Squid": "Squid",
    "19_Starfish": "Starfish",
    "21_Whale": "Whale",
    "27_Diver": "Diver",
    "29_Holothurian": "Holothurian",
    "30_Echinus": "Echinus",
    "32_Sea_Lion": "Sea_Lion",
    "33_Sea_Anemone": "Sea_Anemone",
    "34_Cuttle_fish": "Cuttle_fish",
}

UNIFIED_ID = {name: i for i, name in enumerate(UNIFIED_CLASSES)}

def load_coco(json_path: Path) -> dict:
    with open(json_path, "r", encoding="utf-8") as f:
        return json.load(f)

def build_keep_cat_ids(coco: dict) -> dict:
    """
    Returns mapping: old_category_id -> new_unified_id, for categories we keep.
    """
    keep = {}
    for c in coco.get("categories", []):
        old_id = c["id"]
        old_name = c["name"]
        if old_name in NAME_MAP:
            unified_name = NAME_MAP[old_name]
            keep[old_id] = UNIFIED_ID[unified_name]
    return keep

def filter_and_remap(coco: dict, keep_map: dict, image_dir: Path):
    """
    Filters annotations to kept categories, remaps category_id to unified IDs,
    returns (images, annotations) that are valid and present on disk.
    """
    # Build image_id -> image record (only if file exists)
    images_by_id = {}
    for im in coco.get("images", []):
        fn = im["file_name"]
        p = image_dir / fn
        if p.exists():
            images_by_id[im["id"]] = dict(im)

    # Filter + remap annotations
    anns_out = []
    used_image_ids = set()
    for ann in coco.get("annotations", []):
        old_cat = ann["category_id"]
        if old_cat not in keep_map:
            continue
        img_id = ann["image_id"]
        if img_id not in images_by_id:
            continue
        new_ann = dict(ann)
        new_ann["category_id"] = keep_map[old_cat]
        anns_out.append(new_ann)
        used_image_ids.add(img_id)

    # Keep only images that still have at least one kept annotation
    imgs_out = [images_by_id[i] for i in sorted(used_image_ids)]
    return imgs_out, anns_out

def collect_all():
    sources = []

    # DUO splits
    sources.append((DUO_ROOT / "train" / "_annotations.coco.json", DUO_ROOT / "train"))
    sources.append((DUO_ROOT / "test"  / "_annotations.coco.json", DUO_ROOT / "test"))

    # RUOD splits
    sources.append((RUOD_ROOT / "train" / "_annotations.coco.json", RUOD_ROOT / "train"))
    sources.append((RUOD_ROOT / "valid" / "_annotations.coco.json", RUOD_ROOT / "valid"))
    sources.append((RUOD_ROOT / "test"  / "_annotations.coco.json", RUOD_ROOT / "test"))

    all_images = []
    all_anns = []

    for jp, img_dir in sources:
        if not jp.exists():
            raise FileNotFoundError(f"Missing: {jp}")
        coco = load_coco(jp)
        keep_map = build_keep_cat_ids(coco)
        imgs, anns = filter_and_remap(coco, keep_map, img_dir)

        # Store with absolute source dir so we can copy later
        for im in imgs:
            im["_src_dir"] = str(img_dir)  # temp field
        all_images.extend(imgs)
        all_anns.extend(anns)

    return all_images, all_anns

def reindex_images_and_anns(images, anns):
    # Make image_id unique and sequential
    # Use (src_dir + file_name) as unique key
    key_to_newid = {}
    new_images = []
    next_img_id = 0

    for im in images:
        key = (im["_src_dir"], im["file_name"])
        if key in key_to_newid:
            continue
        key_to_newid[key] = next_img_id
        new_im = {k: v for k, v in im.items() if k != "_src_dir"}
        new_im["id"] = next_img_id
        new_im["_src_dir"] = im["_src_dir"]  # keep for copy stage
        new_images.append(new_im)
        next_img_id += 1

    # Map old (src_dir, old_image_id) is not available reliably across merges,
    # so we map annotations via filename: need filename lookup by old image id per source.
    # We can do that by building reverse map from combined images list we already have:
    # ann.image_id currently references original IDs, but we lost per-source scope.
    # Solution: rebuild anns by matching on (source dir + file_name). We need that linkage.
    #
    # Easiest robust approach: rebuild annotations per source earlier.
    # For simplicity here, we’ll assume original image ids are unique within each json,
    # but across sources they may collide. So we rebuild using filename-based match:
    # We'll create a map from (any source dir, file_name) -> new_id from new_images.
    file_to_newid = {}
    for im in new_images:
        file_to_newid[(im["_src_dir"], im["file_name"])] = im["id"]

    # To remap annotations we need the source dir of each ann. Not present in COCO.
    # So we add it earlier by encoding it into ann["_src_dir"] during collection.
    # We'll do that now: re-collect with ann src dir stored.

    return new_images, key_to_newid

def main():
    random.seed(SEED)

    # Output dirs
    (OUT_ROOT / "images" / "train").mkdir(parents=True, exist_ok=True)
    (OUT_ROOT / "images" / "val").mkdir(parents=True, exist_ok=True)
    (OUT_ROOT / "images" / "test").mkdir(parents=True, exist_ok=True)
    (OUT_ROOT / "annotations").mkdir(parents=True, exist_ok=True)

    # Re-collect but keep per-source context for annotation remap
    sources = [
        (DUO_ROOT / "train" / "_annotations.coco.json", DUO_ROOT / "train"),
        (DUO_ROOT / "test"  / "_annotations.coco.json", DUO_ROOT / "test"),
        (RUOD_ROOT / "train" / "_annotations.coco.json", RUOD_ROOT / "train"),
        (RUOD_ROOT / "valid" / "_annotations.coco.json", RUOD_ROOT / "valid"),
        (RUOD_ROOT / "test"  / "_annotations.coco.json", RUOD_ROOT / "test"),
    ]

    combined_images = []
    combined_anns = []

    for jp, img_dir in sources:
        coco = load_coco(jp)
        keep_map = build_keep_cat_ids(coco)

        # image_id -> file_name for this source
        img_id_to_fn = {im["id"]: im["file_name"] for im in coco.get("images", [])}

        imgs, anns = filter_and_remap(coco, keep_map, img_dir)

        # Attach src_dir to images (for copying) and annotations (for later remap)
        for im in imgs:
            im["_src_dir"] = str(img_dir)

        for ann in anns:
            ann["_src_dir"] = str(img_dir)
            ann["_file_name"] = img_id_to_fn.get(ann["image_id"])

        combined_images.extend(imgs)
        combined_anns.extend(anns)

    # Unique images by (src_dir, file_name)
    uniq = {}
    for im in combined_images:
        key = (im["_src_dir"], im["file_name"])
        if key not in uniq:
            uniq[key] = im

    uniq_images = list(uniq.values())
    random.shuffle(uniq_images)

    n = len(uniq_images)
    n_train = int(SPLIT[0] * n)
    n_val   = int(SPLIT[1] * n)
    train_set = uniq_images[:n_train]
    val_set   = uniq_images[n_train:n_train+n_val]
    test_set  = uniq_images[n_train+n_val:]

    def index_split(split_images):
        # New image IDs sequential within full dataset
        # We'll assign global IDs once, then write split JSONs with subset.
        return split_images

    # Assign global IDs
    key_to_newid = {}
    all_images_ordered = train_set + val_set + test_set
    for new_id, im in enumerate(all_images_ordered):
        key_to_newid[(im["_src_dir"], im["file_name"])] = new_id
        im["id"] = new_id

    # Remap annotations to new image IDs and filter to images that ended up in each split
    split_keys = {
        "train": set((im["_src_dir"], im["file_name"]) for im in train_set),
        "val":   set((im["_src_dir"], im["file_name"]) for im in val_set),
        "test":  set((im["_src_dir"], im["file_name"]) for im in test_set),
    }

    def build_split_json(split_name, split_images):
        keys = split_keys[split_name]
        images_out = []
        for im in split_images:
            out_im = {k: v for k, v in im.items() if k != "_src_dir"}
            images_out.append(out_im)

        anns_out = []
        ann_id = 0
        for ann in combined_anns:
            src = ann.get("_src_dir")
            fn = ann.get("_file_name")
            if not fn:
                continue
            key = (src, fn)
            if key not in keys:
                continue
            new_ann = {k: v for k, v in ann.items() if not k.startswith("_")}
            new_ann["id"] = ann_id
            new_ann["image_id"] = key_to_newid[key]
            anns_out.append(new_ann)
            ann_id += 1

        coco_out = {
            "info": {"description": "Merged DUO+RUOD marine-only dataset", "version": "1.0"},
            "licenses": [{"id": 1, "name": "CC BY 4.0"}],
            "categories": [{"id": i, "name": name, "supercategory": "marine"} for i, name in enumerate(UNIFIED_CLASSES)],
            "images": images_out,
            "annotations": anns_out,
        }
        return coco_out

    # Copy images + write JSONs
    for split_name, split_images, out_dir in [
        ("train", train_set, OUT_ROOT / "images" / "train"),
        ("val",   val_set,   OUT_ROOT / "images" / "val"),
        ("test",  test_set,  OUT_ROOT / "images" / "test"),
    ]:
        for im in split_images:
            src_path = Path(im["_src_dir"]) / im["file_name"]
            dst_path = out_dir / im["file_name"]
            if not dst_path.exists():
                shutil.copy2(src_path, dst_path)

        coco_split = build_split_json(split_name, split_images)
        out_json = OUT_ROOT / "annotations" / f"instances_{split_name}.json"
        with open(out_json, "w", encoding="utf-8") as f:
            json.dump(coco_split, f, indent=2)

    print("Done.")
    print(f"Train images: {len(train_set)} | Val images: {len(val_set)} | Test images: {len(test_set)}")
    print(f"Output: {OUT_ROOT}")

if __name__ == "__main__":
    main()