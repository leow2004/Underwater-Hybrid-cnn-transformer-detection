import fiftyone as fo
import fiftyone.types as fot

dataset_dir = r"D:\DataSetPrep\Hybrid_Marine_COCO"

dataset = fo.Dataset.from_dir(
    dataset_type=fot.COCODetectionDataset,
    data_path=dataset_dir + r"\images\train",
    labels_path=dataset_dir + r"\annotations\instances_train.json",
)

session = fo.launch_app(dataset)
session.wait()