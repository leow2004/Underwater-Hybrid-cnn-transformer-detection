import pandas as pd
from pathlib import Path
import matplotlib.pyplot as plt
import matplotlib.image as mpimg

AUDIT_ROOT = Path(r"D:\DataSetPrep\Hybrid_Marine_COCO\audit_export_unique_v2")
CSV_PATH = Path(r"D:\DataSetPrep\label_noise_audit.csv")

df = pd.read_csv(CSV_PATH, dtype=str)

df["judgement"] = df["judgement"].astype("object")

mask = df["judgement"].isna() | (df["judgement"].astype(str).str.strip() == "")
to_label = df[mask].index.tolist()

print("Instructions:")
print("c = correct")
print("w = wrong")
print("u = unsure")
print("s = skip")
print("q = quit")

for idx in to_label:

    cls = df.at[idx, "class"]
    img_name = df.at[idx, "image"]

    img_path = AUDIT_ROOT / cls / img_name

    if not img_path.exists():
        df.at[idx, "judgement"] = "skip"
        df.to_csv(CSV_PATH, index=False)
        continue

    img = mpimg.imread(str(img_path))

    plt.figure(figsize=(7,7))
    plt.imshow(img)
    plt.axis("off")
    plt.title(f"{cls} | {img_name}")
    plt.show(block=False)

    key = input("Enter judgement (c/w/u/s/q): ").strip().lower()

    plt.close()

    if key == "q":
        break
    elif key == "c":
        df.at[idx, "judgement"] = "correct"
    elif key == "w":
        df.at[idx, "judgement"] = "wrong"
    elif key == "u":
        df.at[idx, "judgement"] = "unsure"
    else:
        df.at[idx, "judgement"] = "skip"

    df.to_csv(CSV_PATH, index=False)

print("Saved progress to:", CSV_PATH)