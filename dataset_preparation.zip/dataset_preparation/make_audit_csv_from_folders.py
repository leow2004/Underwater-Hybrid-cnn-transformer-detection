import csv
from pathlib import Path

AUDIT_ROOT = Path(r"D:\DataSetPrep\Hybrid_Marine_COCO\audit_export_unique_v2")
OUT_CSV = Path(r"D:\DataSetPrep\label_noise_audit.csv")

TARGET_CLASSES = [
    "Clam",  "fish", "Stingray", "Sea-Urchin", "Squid", "Starfish"
]
N = 50

with open(OUT_CSV, "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["class", "image", "judgement", "notes"])

    for cls in TARGET_CLASSES:
        cls_dir = AUDIT_ROOT / cls
        if not cls_dir.exists():
            print(f"Missing folder: {cls_dir}")
            continue

        imgs = sorted([p.name for p in cls_dir.glob("*.png")])[:N]
        for img in imgs:
            w.writerow([cls, img, "", ""])  # judgement left blank for you

print("Wrote:", OUT_CSV)