import json
from collections import Counter

ANN = r"D:\DataSetPrep\Hybrid_Marine_COCO\annotations\instances_train_final.json"

with open(ANN, "r", encoding="utf-8") as f:
    coco = json.load(f)

id2name = {c["id"]: c["name"] for c in coco["categories"]}
counts = Counter()

for ann in coco["annotations"]:
    counts[id2name[ann["category_id"]]] += 1

print("\nFinal class distribution:\n")
for c in coco["categories"]:
    print(f"{c['name']:15s} {counts.get(c['name'], 0)}")