import json, random
from pathlib import Path
import cv2
import matplotlib.pyplot as plt

ROOT = Path(r"D:\DataSetPrep\Hybrid_Marine_COCO")
ANN = ROOT / "annotations" / "instances_train_clean.json"
IMG_DIR = ROOT / "images" / "train"
OUT = ROOT / "audit_export"
OUT.mkdir(exist_ok=True)

SAMPLES_PER_CLASS = 60   # 50–100 is fine
SEED = 42
random.seed(SEED)

with open(ANN, "r", encoding="utf-8") as f:
    coco = json.load(f)

id_to_name = {c["id"]: c["name"] for c in coco["categories"]}
images = {im["id"]: im for im in coco["images"]}

# group annotations by class
anns_by_class = {}
for ann in coco["annotations"]:
    anns_by_class.setdefault(ann["category_id"], []).append(ann)

def draw_and_save(img_path, ann, out_path):
    img = cv2.imread(str(img_path))
    if img is None:
        return False
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    x, y, w, h = map(int, ann["bbox"])
    label = id_to_name[ann["category_id"]]
    cv2.rectangle(img, (x, y), (x+w, y+h), (0, 255, 0), 2)
    cv2.putText(img, label, (x, max(0, y-5)),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,0), 2)

    plt.figure(figsize=(6,6))
    plt.imshow(img)
    plt.axis("off")
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()
    return True

for cid, anns in anns_by_class.items():
    cname = id_to_name[cid]
    class_dir = OUT / cname
    class_dir.mkdir(parents=True, exist_ok=True)

    sample = random.sample(anns, min(SAMPLES_PER_CLASS, len(anns)))
    for i, ann in enumerate(sample):
        im = images[ann["image_id"]]
        img_path = IMG_DIR / im["file_name"]
        out_path = class_dir / f"{i:03d}_{im['file_name']}.png"
        draw_and_save(img_path, ann, out_path)

print("Audit export complete:", OUT)